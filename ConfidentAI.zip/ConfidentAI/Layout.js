
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Mic, BarChart3, Target, User, Brain } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: Home,
  },
  {
    title: "Practice",
    url: createPageUrl("Practice"),
    icon: Mic,
  },
  {
    title: "Analytics",
    url: createPageUrl("Analytics"),
    icon: BarChart3,
  },
  {
    title: "Profile",
    url: createPageUrl("Profile"),
    icon: User,
  },
];

export default function Layout({ children }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <style>
        {`
          :root {
            --confident-primary: #6366f1;
            --confident-secondary: #8b5cf6;
            --confident-accent: #06b6d4;
            --confident-success: #10b981;
            --confident-warning: #f59e0b;
            --confident-calm-blue: #eff6ff;
            --confident-soft-gray: #f8fafc;
            --confident-warm-white: #fefefe;
          }
          
          .confident-gradient {
            background: linear-gradient(135deg, var(--confident-primary) 0%, var(--confident-secondary) 100%);
          }
          
          .confident-glass {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
          
          .confident-shadow {
            box-shadow: 0 8px 32px rgba(99, 102, 241, 0.1);
          }
        `}
      </style>
      
      <div className="min-h-screen flex w-full" style={{ backgroundColor: 'var(--confident-soft-gray)' }}>
        <Sidebar className="border-r border-indigo-100">
          <SidebarHeader className="border-b border-indigo-100 p-6">
            <div className="flex items-center gap-3">
              <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect width="44" height="44" rx="12" fill="url(#logo-gradient)"/>
                <path d="M15 25.5C17.5 25.5 18.5 20.5 21 20.5C23.5 20.5 24.5 25.5 27 25.5C29.5 25.5 30.5 20.5 33 20.5" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" opacity="0.7"/>
                <path d="M22 21V14M22 14L19 17M22 14L25 17" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                <defs>
                  <linearGradient id="logo-gradient" x1="0" y1="0" x2="44" y2="44" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#6366F1"/>
                    <stop offset="1" stopColor="#8B5CF6"/>
                  </linearGradient>
                </defs>
              </svg>
              <div>
                <h2 className="font-bold text-xl text-gray-900">Confident.AI</h2>
                <p className="text-sm text-indigo-600 font-medium">Speech Coach</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`mb-2 rounded-xl transition-all duration-300 hover:bg-indigo-50 hover:text-indigo-700 ${
                          location.pathname === item.url ? 'bg-indigo-100 text-indigo-700 shadow-sm' : 'text-gray-600'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <div className="mt-8 p-4 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-100">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-indigo-600" />
                <span className="text-sm font-semibold text-indigo-900">Today's Goal</span>
              </div>
              <p className="text-sm text-indigo-700">
                Practice for 10 minutes to build confidence
              </p>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-sm border-b border-indigo-100 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-indigo-50 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-gray-900">Confident.AI</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
