import React, { useState } from "react";
import { InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { BrainCircuit, Edit, Sparkles } from "lucide-react";

export default function TopicSelection({ module, onTopicConfirm, onBack }) {
  const [userTopic, setUserTopic] = useState("");
  const [isGeneratingTopic, setIsGeneratingTopic] = useState(false);

  const handleGenerateTopic = async () => {
    setIsGeneratingTopic(true);
    try {
      const topic = await InvokeLLM({
        prompt: "Generate one interesting and engaging speech topic suitable for someone practicing public speaking. The topic should be something a person can talk about for a few minutes. Make it a single, concise sentence.",
      });
      onTopicConfirm(topic);
    } catch (error) {
      console.error("Error generating topic:", error);
      // Fallback to a static topic on error
      onTopicConfirm("Describe a place you would love to visit.");
    } finally {
      setIsGeneratingTopic(false);
    }
  };

  const handleUserTopicSubmit = (e) => {
    e.preventDefault();
    if (userTopic.trim()) {
      onTopicConfirm(userTopic.trim());
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <Button 
          variant="outline" 
          onClick={onBack}
          className="border-indigo-200 text-indigo-700 hover:bg-indigo-50 mb-4"
        >
          ← Back to Modules
        </Button>
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">Choose Your Topic</h2>
        <p className="text-gray-600">How would you like to get a topic for your speech practice?</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* AI Suggested Topic */}
        <Card className="confident-glass border-0 confident-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <BrainCircuit className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Suggested Topic</h3>
            <p className="text-gray-600 text-sm mb-4">Let our AI generate a creative and engaging topic for you.</p>
            <Button 
              onClick={handleGenerateTopic} 
              disabled={isGeneratingTopic}
              className="w-full confident-gradient text-white hover:opacity-90"
            >
              {isGeneratingTopic ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              Generate Topic
            </Button>
          </CardContent>
        </Card>

        {/* User Defined Topic */}
        <Card className="confident-glass border-0 confident-shadow">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Edit className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Use Your Own Topic</h3>
            <p className="text-gray-600 text-sm mb-4">Have something specific in mind? Enter your own topic below.</p>
            <form onSubmit={handleUserTopicSubmit} className="flex gap-2">
              <Input 
                placeholder="e.g., My summer vacation" 
                value={userTopic}
                onChange={(e) => setUserTopic(e.target.value)}
              />
              <Button type="submit" variant="outline" className="border-indigo-200 text-indigo-700 hover:bg-indigo-50">
                Start
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}