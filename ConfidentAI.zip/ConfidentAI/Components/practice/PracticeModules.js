import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, 
  Briefcase, 
  Presentation,
  ArrowRight,
  Clock,
  Target
} from "lucide-react";

const practiceModules = [
  {
    id: "speech_practice",
    name: "Speech Practice",
    type: "speech_practice",
    icon: MessageSquare,
    description: "Practice general speaking skills with AI-generated topics",
    duration: "5-10 minutes",
    difficulty: "Beginner Friendly",
    topics: [
      "Describe your ideal weekend",
      "Talk about a book that influenced you", 
      "Explain your hobby to someone new",
      "Discuss the importance of teamwork",
      "Share your thoughts on technology's impact",
      "Describe your dream vacation destination",
      "Talk about a skill you'd like to learn",
      "Explain why learning is important",
      "Describe your favorite childhood memory",
      "Talk about a person who inspires you"
    ]
  },
  {
    id: "mock_interview",
    name: "Mock Interview",
    type: "mock_interview", 
    icon: Briefcase,
    description: "Practice interview responses with varied questions",
    duration: "10-15 minutes",
    difficulty: "Intermediate",
    topics: [
      "Tell me about yourself and your background",
      "Why are you interested in this position?",
      "What are your greatest strengths?",
      "Describe a challenging situation you overcame",
      "Where do you see yourself in 5 years?",
      "What motivates you in your work?",
      "Tell me about a time you failed and what you learned",
      "How do you handle stress and pressure?",
      "What makes you unique compared to other candidates?",
      "Describe a time you had to work with a difficult team member",
      "What's your biggest weakness and how are you improving it?",
      "Tell me about a project you're particularly proud of",
      "How do you prioritize your tasks when everything seems urgent?",
      "Describe a time you had to learn something completely new",
      "Why are you leaving your current position?",
      "What questions do you have for me?",
      "How do you handle constructive criticism?",
      "Tell me about a time you had to make a difficult decision",
      "What are your salary expectations?",
      "How do you stay current with industry trends?"
    ]
  },
  {
    id: "presentation",
    name: "Presentation Skills",
    type: "presentation",
    icon: Presentation,
    description: "Improve your presentation delivery and structure",
    duration: "5-20 minutes",
    difficulty: "Advanced",
    topics: [
      "Present a product idea to investors",
      "Explain a complex concept simply",
      "Give a project status update",
      "Deliver quarterly results",
      "Introduce a new team member",
      "Present a budget proposal",
      "Explain a new company policy",
      "Pitch a marketing campaign",
      "Present research findings",
      "Deliver a training session overview"
    ]
  }
];

export default function PracticeModules({ onSelectModule }) {
  const handleModuleSelect = (module) => {
    // For speech practice, let the user choose the topic on the next screen.
    if (module.id === 'speech_practice') {
      onSelectModule(module);
      return;
    }

    // For other modules, select a random topic
    const randomTopic = module.topics[Math.floor(Math.random() * module.topics.length)];
    onSelectModule({
      ...module,
      topic: randomTopic
    });
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Choose Practice Module</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {practiceModules.map((module) => {
          const IconComponent = module.icon;
          return (
            <Card key={module.id} className="confident-glass border-0 confident-shadow hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{module.name}</h3>
                    <Badge variant="outline" className="text-xs mt-1">
                      {module.difficulty}
                    </Badge>
                  </div>
                </div>

                <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                  {module.description}
                </p>

                <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {module.duration}
                  </div>
                  <div className="flex items-center gap-1">
                    <Target className="w-4 h-4" />
                    {module.topics.length} topics
                  </div>
                </div>

                <Button
                  onClick={() => handleModuleSelect(module)}
                  className="w-full confident-gradient text-white hover:opacity-90 transition-all duration-300 group-hover:shadow-md"
                >
                  Start Practice
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}