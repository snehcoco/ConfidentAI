
import React, { useState, useRef, useEffect } from "react";
import { Session } from "@/entities/Session";
import { InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Mic, 
  Square, 
  Play, 
  Pause,
  Clock,
  AlertCircle,
  Zap
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

import FeedbackDisplay from "./FeedbackDisplay";

export default function RecordingInterface({ moduleType = "free_practice", topic = null }) {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [error, setError] = useState("");
  const [transcription, setTranscription] = useState("");
  
  const mediaRecorderRef = useRef(null);
  const audioRef = useRef(null);
  const streamRef = useRef(null);
  const intervalRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    // Cleanup function to stop recording and recognition if the component unmounts
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const options = { mimeType: 'audio/webm' };
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;

      const chunks = [];
      mediaRecorder.ondataavailable = (event) => chunks.push(event.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setAudioBlob(blob);
        setAudioUrl(URL.createObjectURL(blob));
      };

      mediaRecorder.start();
      setIsRecording(true);
      setDuration(0);
      setError("");
      setTranscription("");

      startSpeechRecognition();

      intervalRef.current = setInterval(() => setDuration(prev => prev + 1), 1000);
    } catch (err) {
      setError("Could not access microphone. Please check permissions and try again.");
      console.error("Error starting recording:", err);
    }
  };

  const startSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window)) {
      setError("Speech recognition is not supported by your browser. Please try Google Chrome.");
      return;
    }
    
    const recognition = new window.webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false; // We only want the final transcript
    recognition.lang = 'en-US';

    let finalTranscript = '';
    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript + ' ';
        }
      }
    };
    
    recognition.onend = () => {
      setTranscription(finalTranscript.trim());
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) mediaRecorderRef.current.stop();
    if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (recognitionRef.current) recognitionRef.current.stop();
    setIsRecording(false);
  };

  const togglePlayback = () => {
    if (audioRef.current) {
      isPlaying ? audioRef.current.pause() : audioRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  const analyzeRecording = async () => {
    // HONESTY CHECK: Ensure transcription captured something meaningful.
    if (!transcription || transcription.trim().split(' ').length < 2) {
      setError("No significant speech was detected. Please record again, speaking clearly.");
      return;
    }

    setIsAnalyzing(true);
    setError("");
    
    try {
      const sessionType = moduleType.replace('_', ' ');
      const analysisPrompt = `
        You are an expert speech coach analyzing the following speech transcript. The user is practicing to overcome speech introversion, so be encouraging but also provide honest, specific, and actionable feedback.

        Session Details:
        - Type: ${sessionType}
        - Topic: "${topic || 'Free practice'}"
        - Duration: ${duration} seconds

        Transcript to Analyze:
        ---
        ${transcription}
        ---
        
        Based ONLY on the provided transcript and session details, generate a JSON response with:
        - clarity_score (0-100): How clear and coherent is the message?
        - pace_score (0-100): Estimate pace.
        - tone_score (0-100): Based on word choice, how confident and engaging does the user sound?
        - overall_score (0-100): A weighted average.
        - filler_count (number): Count ONLY unambiguous filler words (e.g., um, uh, ah, er). Be very conservative. If a word like 'so' or 'like' is used grammatically, DO NOT count it. If unsure, do not count it.
        - feedback (string): A summary of your analysis with encouraging and constructive advice.
        - strengths (array of strings): 2-3 specific things the user did well in their speech.
        - improvements (array of strings): 2-3 specific, actionable areas for improvement.
        - filler_words (array of objects with 'word' and 'count'): List of DETECTED UNAMBIGUOUS filler words and their counts.
      `;

      const analysisData = await InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            clarity_score: { type: "number" },
            pace_score: { type: "number" },
            tone_score: { type: "number" },
            overall_score: { type: "number" },
            filler_count: { type: "number" },
            feedback: { type: "string" },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            filler_words: {
              type: "array",
              items: {
                type: "object",
                properties: { word: { type: "string" }, count: { type: "number" } }
              }
            }
          }
        }
      });

      setAnalysisResult({
        ...analysisData,
        transcript: transcription,
        duration: duration,
      });

    } catch (err) {
      setError("Analysis failed. Please try again.");
      console.error("Analysis error:", err);
    }
    setIsAnalyzing(false);
  };

  const saveSession = async () => {
    if (!analysisResult) return;

    try {
      await Session.create({
        title: `${moduleType.replace('_', ' ')} Session - ${topic || new Date().toLocaleDateString()}`,
        type: moduleType,
        transcript: analysisResult.transcript,
        duration: analysisResult.duration,
        clarity_score: analysisResult.clarity_score,
        pace_score: analysisResult.pace_score,
        tone_score: analysisResult.tone_score,
        filler_count: analysisResult.filler_count,
        overall_score: analysisResult.overall_score,
        ai_feedback: analysisResult.feedback,
        filler_words: analysisResult.filler_words,
        topic: topic || "Free practice"
      });

      // Reset for next session
      setAudioBlob(null);
      setAudioUrl(null);
      setAnalysisResult(null);
      setDuration(0);
      setTranscription("");
      
    } catch (err) {
      setError("Error saving session. Please try again.");
      console.error("Save error:", err);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (analysisResult) {
    return (
      <FeedbackDisplay 
        result={analysisResult}
        onSave={saveSession}
        onStartNew={() => {
          setAnalysisResult(null);
          setAudioBlob(null);
          setAudioUrl(null);
          setDuration(0);
          setTranscription("");
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-indigo-600" />
            Voice Recording
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 rounded-full flex items-center justify-center relative">
              <div className={`w-full h-full rounded-full border-4 transition-all duration-300 ${
                isRecording 
                  ? 'border-red-400 bg-red-50 animate-pulse' 
                  : 'border-indigo-300 bg-indigo-50'
              }`}>
                <div className="w-full h-full rounded-full flex items-center justify-center">
                  {!isRecording ? (
                    <Button
                      onClick={startRecording}
                      size="lg"
                      className="w-16 h-16 rounded-full confident-gradient text-white hover:opacity-90"
                    >
                      <Mic className="w-6 h-6" />
                    </Button>
                  ) : (
                    <Button
                      onClick={stopRecording}
                      size="lg"
                      variant="destructive"
                      className="w-16 h-16 rounded-full"
                    >
                      <Square className="w-6 h-6" />
                    </Button>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-lg font-semibold text-gray-900">
              <Clock className="w-5 h-5" />
              {formatTime(duration)}
            </div>

            {isRecording && (
              <div className="text-center">
                <Badge className="bg-red-100 text-red-800 animate-pulse mb-2">
                  Recording... Speak Now
                </Badge>
              </div>
            )}
          </div>

          {audioUrl && !isRecording && (
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-gray-900">Recording Playback</h4>
                <Button
                  onClick={togglePlayback}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isPlaying ? 'Pause' : 'Play'}
                </Button>
              </div>
              <audio
                ref={audioRef}
                src={audioUrl}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
                className="w-full"
                controls
              />
            </div>
          )}

          {audioBlob && !isRecording && (
            <div className="flex gap-4">
              <Button
                onClick={analyzeRecording}
                disabled={isAnalyzing}
                className="flex-1 confident-gradient text-white hover:opacity-90"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Analyzing Performance...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Get AI Feedback
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
