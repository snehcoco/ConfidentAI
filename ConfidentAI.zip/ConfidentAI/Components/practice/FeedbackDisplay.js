import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Award, 
  TrendingUp, 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Save,
  RotateCcw
} from "lucide-react";

export default function FeedbackDisplay({ result, onSave, onStartNew }) {
  const getScoreColor = (score) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreLabel = (score) => {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Good";
    return "Needs Work";
  };

  return (
    <div className="space-y-6">
      {/* Overall Score */}
      <Card className="confident-gradient text-white border-0 confident-shadow">
        <CardContent className="p-8 text-center">
          <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Award className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-3xl font-bold mb-2">{result.overall_score}%</h2>
          <p className="text-white/90 text-lg">Overall Performance</p>
          <Badge className="mt-3 bg-white/20 text-white border-white/30">
            {getScoreLabel(result.overall_score)}
          </Badge>
        </CardContent>
      </Card>

      {/* Skill Breakdown */}
      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
            Skill Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">Clarity</span>
                <span className={`text-sm font-bold ${getScoreColor(result.clarity_score)}`}>
                  {result.clarity_score}%
                </span>
              </div>
              <Progress value={result.clarity_score} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">Pace</span>
                <span className={`text-sm font-bold ${getScoreColor(result.pace_score)}`}>
                  {result.pace_score}%
                </span>
              </div>
              <Progress value={result.pace_score} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">Tone</span>
                <span className={`text-sm font-bold ${getScoreColor(result.tone_score)}`}>
                  {result.tone_score}%
                </span>
              </div>
              <Progress value={result.tone_score} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Strengths */}
        {result.strengths && result.strengths.length > 0 && (
          <Card className="confident-glass border-0 confident-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-700">
                <CheckCircle className="w-5 h-5" />
                What You Did Well
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.strengths.map((strength, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{strength}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Areas for Improvement */}
        {result.improvements && result.improvements.length > 0 && (
          <Card className="confident-glass border-0 confident-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-700">
                <AlertTriangle className="w-5 h-5" />
                Areas to Improve
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.improvements.map((improvement, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{improvement}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>

      {/* AI Feedback */}
      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-600" />
            Detailed Feedback
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">{result.feedback}</p>
        </CardContent>
      </Card>

      {/* Filler Words */}
      {result.filler_words && result.filler_words.length > 0 && (
        <Card className="confident-glass border-0 confident-shadow">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-600" />
              Filler Word Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2 mb-4">
              {result.filler_words.map((filler, index) => (
                <Badge key={index} variant="outline" className="border-orange-200 text-orange-800">
                  "{filler.word}" - {filler.count} times
                </Badge>
              ))}
            </div>
            <p className="text-sm text-gray-600">
              Total filler words detected: <span className="font-semibold">{result.filler_count}</span>
            </p>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button
          onClick={onSave}
          className="flex-1 confident-gradient text-white hover:opacity-90"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Session
        </Button>
        <Button
          onClick={onStartNew}
          variant="outline"
          className="flex-1 border-indigo-200 text-indigo-700 hover:bg-indigo-50"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          New Session
        </Button>
      </div>
    </div>
  );
}