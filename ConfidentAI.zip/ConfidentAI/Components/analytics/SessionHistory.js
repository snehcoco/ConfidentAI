import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import { History, Clock, Award } from "lucide-react";

const typeColors = {
  speech_practice: "bg-blue-100 text-blue-800 border-blue-200",
  mock_interview: "bg-purple-100 text-purple-800 border-purple-200",
  presentation: "bg-emerald-100 text-emerald-800 border-emerald-200"
};

export default function SessionHistory({ sessions, isLoading }) {
  if (isLoading) {
    return (
      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-indigo-600" />
            Session History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-12 bg-gray-200 rounded-lg" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="confident-glass border-0 confident-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5 text-indigo-600" />
          Session History
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-64">
          {sessions.length === 0 ? (
            <div className="text-center py-8">
              <History className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No sessions yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {sessions.slice(0, 10).map((session) => (
                <div key={session.id} className="p-3 bg-white/60 rounded-lg border border-white/20">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm text-gray-900 truncate">
                      {session.title}
                    </h4>
                    <div className="flex items-center gap-1">
                      <Award className="w-3 h-3 text-amber-500" />
                      <span className="text-sm font-semibold text-gray-900">
                        {session.overall_score || 0}%
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className={`${typeColors[session.type]} text-xs`}>
                        {session.type.replace('_', ' ')}
                      </Badge>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        {Math.round((session.duration || 0) / 60)}m
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">
                      {format(new Date(session.created_date), 'MMM d, yyyy')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}