import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, TrendingUp, Target, AlertTriangle } from "lucide-react";

export default function InsightsPanel({ sessions }) {
  const generateInsights = () => {
    if (!sessions.length) {
      return [
        {
          type: "info",
          icon: Target,
          title: "Welcome to Confident.AI!",
          description: "Start your first practice session to begin tracking your progress.",
          color: "text-blue-600"
        }
      ];
    }

    const insights = [];
    const avgScore = sessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / sessions.length;
    const avgClarity = sessions.reduce((sum, s) => sum + (s.clarity_score || 0), 0) / sessions.length;
    const avgPace = sessions.reduce((sum, s) => sum + (s.pace_score || 0), 0) / sessions.length;
    const avgTone = sessions.reduce((sum, s) => sum + (s.tone_score || 0), 0) / sessions.length;

    // Performance insight
    if (avgScore >= 80) {
      insights.push({
        type: "success",
        icon: TrendingUp,
        title: "Excellent Performance!",
        description: `Your average score of ${Math.round(avgScore)}% shows strong speaking skills. Keep practicing to maintain this level.`,
        color: "text-green-600"
      });
    } else if (avgScore >= 60) {
      insights.push({
        type: "improvement",
        icon: Target,
        title: "Making Good Progress",
        description: `Your average score of ${Math.round(avgScore)}% is improving. Focus on consistency to reach the next level.`,
        color: "text-blue-600"
      });
    } else {
      insights.push({
        type: "attention",
        icon: AlertTriangle,
        title: "Room for Growth",
        description: `Your average score of ${Math.round(avgScore)}% shows potential. Regular practice will help build confidence.`,
        color: "text-amber-600"
      });
    }

    // Skill-specific insights
    const lowestSkill = Math.min(avgClarity, avgPace, avgTone);
    let skillToImprove = "";
    if (lowestSkill === avgClarity) skillToImprove = "clarity";
    else if (lowestSkill === avgPace) skillToImprove = "pace";
    else skillToImprove = "tone";

    insights.push({
      type: "tip",
      icon: Lightbulb,
      title: `Focus on ${skillToImprove.charAt(0).toUpperCase() + skillToImprove.slice(1)}`,
      description: `Your ${skillToImprove} score (${Math.round(lowestSkill)}%) has the most room for improvement. Try specific exercises targeting this area.`,
      color: "text-purple-600"
    });

    // Session frequency insight
    if (sessions.length >= 5) {
      const recent = sessions.slice(0, 3);
      const older = sessions.slice(-3);
      const recentAvg = recent.reduce((sum, s) => sum + (s.overall_score || 0), 0) / recent.length;
      const olderAvg = older.reduce((sum, s) => sum + (s.overall_score || 0), 0) / older.length;
      
      if (recentAvg > olderAvg + 5) {
        insights.push({
          type: "success",
          icon: TrendingUp,
          title: "Upward Trend!",
          description: `Your recent sessions show improvement. You've increased your average by ${Math.round(recentAvg - olderAvg)} points!`,
          color: "text-green-600"
        });
      }
    }

    return insights.slice(0, 3); // Show max 3 insights
  };

  const insights = generateInsights();

  return (
    <Card className="confident-glass border-0 confident-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-indigo-600" />
          AI Insights
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight, index) => {
            const IconComponent = insight.icon;
            return (
              <div key={index} className="p-4 bg-white/60 rounded-lg border border-white/20">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0`}>
                    <IconComponent className={`w-4 h-4 ${insight.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-gray-900 text-sm mb-1">
                      {insight.title}
                    </h4>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {insight.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}