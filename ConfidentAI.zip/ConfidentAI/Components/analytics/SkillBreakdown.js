import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { BarChart3, Award } from "lucide-react";

export default function SkillBreakdown({ sessions, isLoading }) {
  const calculateAverageScores = () => {
    if (!sessions.length) return [];

    const totals = sessions.reduce(
      (acc, session) => ({
        clarity: acc.clarity + (session.clarity_score || 0),
        pace: acc.pace + (session.pace_score || 0),
        tone: acc.tone + (session.tone_score || 0)
      }),
      { clarity: 0, pace: 0, tone: 0 }
    );

    return [
      {
        skill: 'Clarity',
        score: Math.round(totals.clarity / sessions.length),
        color: '#6366f1'
      },
      {
        skill: 'Pace',
        score: Math.round(totals.pace / sessions.length),
        color: '#8b5cf6'
      },
      {
        skill: 'Tone',
        score: Math.round(totals.tone / sessions.length),
        color: '#10b981'
      }
    ];
  };

  const skillData = calculateAverageScores();

  if (isLoading || sessions.length === 0) {
    return (
      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-indigo-600" />
            Skill Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-48 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-center">
              <div>
                <Award className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">No data available</p>
                <p className="text-sm text-gray-500">Complete sessions to see your skill breakdown</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="confident-glass border-0 confident-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-indigo-600" />
          Skill Breakdown
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={skillData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis 
                dataKey="skill" 
                stroke="#6b7280"
                fontSize={12}
              />
              <YAxis 
                stroke="#6b7280"
                fontSize={12}
                domain={[0, 100]}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
                formatter={(value) => [`${value}%`, 'Average Score']}
              />
              <Bar 
                dataKey="score" 
                fill="#6366f1"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}