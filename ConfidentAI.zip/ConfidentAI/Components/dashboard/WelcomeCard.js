import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Target } from "lucide-react";

export default function WelcomeCard({ user }) {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  const getMotivationalMessage = () => {
    const messages = [
      "Ready to build your confidence today?",
      "Every practice session makes you stronger!",
      "Your voice matters - let's make it heard!",
      "Progress, not perfection. Let's practice!",
      "Confidence grows with every word you speak!"
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  return (
    <Card className="confident-gradient text-white border-0 confident-shadow relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full transform translate-x-8 -translate-y-8" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full transform -translate-x-4 translate-y-4" />
      
      <CardContent className="p-8 relative">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-white/80" />
              <span className="text-white/80 font-medium">
                {getGreeting()}, {user?.full_name?.split(' ')[0] || 'there'}!
              </span>
            </div>
            <h2 className="text-2xl font-bold mb-3">
              {getMotivationalMessage()}
            </h2>
            <p className="text-white/90 text-lg">
              Choose a practice session below to continue your speaking journey.
            </p>
          </div>
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
            <Target className="w-8 h-8 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}