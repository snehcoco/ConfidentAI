import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

export default function StatsCards({ title, value, icon: Icon, bgColor, description, trend }) {
  return (
    <Card className="confident-glass border-0 confident-shadow relative overflow-hidden">
      <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${bgColor} opacity-10 rounded-full transform translate-x-8 -translate-y-8`} />
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
            <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
            {description && (
              <p className="text-sm text-gray-500 mb-2">{description}</p>
            )}
            {trend && (
              <p className="text-sm text-indigo-600 font-medium">{trend}</p>
            )}
          </div>
          <div className={`w-12 h-12 bg-gradient-to-br ${bgColor} rounded-xl flex items-center justify-center`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}