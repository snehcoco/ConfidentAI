import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Clock, Mic, Briefcase, Presentation, MessageSquare, Award } from "lucide-react";

const typeIcons = {
  speech_practice: MessageSquare,
  mock_interview: Briefcase,
  presentation: Presentation
};

const typeColors = {
  speech_practice: "bg-blue-100 text-blue-800 border-blue-200",
  mock_interview: "bg-purple-100 text-purple-800 border-purple-200",
  presentation: "bg-emerald-100 text-emerald-800 border-emerald-200"
};

export default function RecentSessions({ sessions, isLoading }) {
  if (isLoading) {
    return (
      <Card className="confident-glass border-0 confident-shadow">
        <CardHeader>
          <CardTitle>Recent Sessions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded-lg" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="confident-glass border-0 confident-shadow">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mic className="w-5 h-5 text-indigo-600" />
          Recent Sessions
        </CardTitle>
      </CardHeader>
      <CardContent>
        {sessions.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-600 mb-2">No practice sessions yet</p>
            <p className="text-sm text-gray-500">Start your first session to see your progress here</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sessions.slice(0, 5).map((session) => {
              const TypeIcon = typeIcons[session.type] || MessageSquare;
              return (
                <div key={session.id} className="flex items-center gap-4 p-4 bg-white/60 rounded-xl border border-white/20">
                  <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                    <TypeIcon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-gray-900 truncate">{session.title}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <Badge className={typeColors[session.type]}>
                        {session.type.replace('_', ' ')}
                      </Badge>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Clock className="w-3 h-3" />
                        {Math.round((session.duration || 0) / 60)}m
                      </div>
                      <span className="text-sm text-gray-500">
                        {format(new Date(session.created_date), 'MMM d')}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-500" />
                    <span className="font-semibold text-gray-900">
                      {session.overall_score || 0}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}