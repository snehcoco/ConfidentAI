
import React, { useState, useEffect } from "react";
import { Session } from "@/entities/Session";
import { User } from "@/entities/User";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Mic,
  TrendingUp,
  Target,
  Award,
  Calendar,
  Download,
  Sparkles,
  ArrowRight
} from "lucide-react";

import StatsCards from "../components/dashboard/StatsCards";
import RecentSessions from "../components/dashboard/RecentSessions";
import WelcomeCard from "../components/dashboard/WelcomeCard";

export default function Dashboard() {
  const [sessions, setSessions] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      
      // Redirect to profile page if preferences are not set
      if (!userData.goal || !userData.experience_level) {
        window.location.href = createPageUrl("Profile");
        return; // Stop loading data on this page
      }
      
      const sessionsData = await Session.filter({ created_by: userData.email }, "-created_date", 10);
      
      setUser(userData);
      setSessions(sessionsData);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    }
    setIsLoading(false);
  };

  const calculateStats = () => {
    if (!sessions || sessions.length < 1) {
      return { totalSessions: 0, avgScore: 0, improvement: 0 };
    }
    
    const totalSessions = sessions.length;
    const avgScore = sessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / totalSessions;
    
    let improvement = 0;

    // Start calculating improvement once there are at least 2 sessions to compare
    if (sessions.length >= 2) {
      // Use a dynamic window size for comparison until there's enough data, then stabilize
      const windowSize = sessions.length >= 6 ? 3 : Math.floor(sessions.length / 2);
      
      const recentSessions = sessions.slice(0, windowSize);
      const olderSessions = sessions.slice(-windowSize);

      const recentAvg = recentSessions.length > 0 ? recentSessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / recentSessions.length : 0;
      const olderAvg = olderSessions.length > 0 ? olderSessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / olderSessions.length : 0;

      // Prevent division by zero and calculate a meaningful improvement percentage
      if (olderAvg > 0) {
        improvement = ((recentAvg - olderAvg) / olderAvg) * 100;
      } else if (recentAvg > 0) {
        // If the user started from a score of 0, any improvement is significant.
        // We'll represent this as a flat 100% to avoid showing "Infinity".
        improvement = 100;
      }
    }
    
    return { 
      totalSessions, 
      avgScore: Math.round(avgScore), 
      improvement: Math.round(improvement)
    };
  };

  const stats = calculateStats();
  
  if (isLoading && !user) {
    return (
      <div className="min-h-screen p-6 flex items-center justify-center" style={{ backgroundColor: 'var(--confident-soft-gray)' }}>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: 'var(--confident-soft-gray)' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        
        <WelcomeCard user={user} />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCards
            title="Total Sessions"
            value={stats.totalSessions}
            icon={Calendar}
            bgColor="from-blue-500 to-blue-600"
            description="Practice sessions completed"
            trend={sessions.length >= 2 ? "+12% this week" : null}
          />
          <StatsCards
            title="Average Score"
            value={`${stats.avgScore}%`}
            icon={Award}
            bgColor="from-purple-500 to-purple-600"
            description="Overall performance"
            trend={stats.avgScore >= 70 ? "Excellent progress!" : stats.avgScore >= 50 ? "Good improvement" : "Keep practicing!"}
          />
          <StatsCards
            title="Improvement"
            value={`${stats.improvement > 0 ? '+' : ''}${stats.improvement}%`}
            icon={TrendingUp}
            bgColor="from-emerald-500 to-emerald-600"
            description="Since you started"
            trend={stats.improvement > 0 ? "You're getting better!" : "Stay consistent"}
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <RecentSessions sessions={sessions} isLoading={isLoading} />
          </div>

          <div className="space-y-6">
            <div className="confident-glass rounded-2xl p-6 confident-shadow">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                  <Target className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">Quick Actions</h3>
              </div>
              <div className="space-y-3">
                <Link to={createPageUrl("Practice")} className="block">
                  <Button className="w-full confident-gradient text-white border-0 hover:opacity-90 transition-all duration-300 group">
                    <Mic className="w-4 h-4 mr-2" />
                    Start Practice Session
                    <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Button>
                </Link>
                <Link to={createPageUrl("Analytics")} className="block">
                  <Button variant="outline" className="w-full border-indigo-200 text-indigo-700 hover:bg-indigo-50">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Progress
                  </Button>
                </Link>
              </div>
            </div>

            <div className="confident-glass rounded-2xl p-6 confident-shadow">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">Daily Motivation</h3>
              </div>
              <p className="text-gray-700 text-sm leading-relaxed mb-4">
                "Every expert was once a beginner. Every pro was once an amateur."
              </p>
              <p className="text-indigo-600 text-xs font-medium">
                You're making progress every day! 🌟
              </p>
            </div>

            <div className="confident-glass rounded-2xl p-6 confident-shadow">
              <h3 className="font-semibold text-gray-900 mb-4">Export Progress</h3>
              <Link to={createPageUrl("Analytics")} className="block">
                <Button 
                  variant="outline" 
                  className="w-full border-gray-200 text-gray-700 hover:bg-gray-50"
                  disabled={sessions.length === 0}
                >
                  <Download className="w-4 h-4 mr-2" />
                  View Full Report
                </Button>
              </Link>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Generate a PDF of your progress
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
