
import React, { useState, useEffect } from "react";
import { Session } from "@/entities/Session";
import { User } from "@/entities/User";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, TrendingUp, Target, Clock, MessageSquare, Brain } from "lucide-react";

import ProgressChart from "../components/analytics/ProgressChart";
import SkillBreakdown from "../components/analytics/SkillBreakdown";
import SessionHistory from "../components/analytics/SessionHistory";
import InsightsPanel from "../components/analytics/InsightsPanel";

// Component for the printable report
const PrintableReport = React.forwardRef(({ sessions, metrics, user }, ref) => {
  return (
    <div ref={ref} className="p-8">
      <div className="flex items-center justify-between mb-8 pb-4 border-b">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
            <Brain className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Confident.AI</h1>
            <p className="text-gray-600">Progress Report</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-semibold">{user?.full_name}</p>
          <p className="text-sm text-gray-500">{new Date().toLocaleDateString()}</p>
        </div>
      </div>

      <h2 className="text-xl font-semibold mb-4 text-gray-800">Performance Summary</h2>
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Total Sessions</p>
          <p className="text-2xl font-bold text-gray-900">{metrics.totalSessions}</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Practice Time</p>
          <p className="text-2xl font-bold text-gray-900">{metrics.totalTime}m</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Average Score</p>
          <p className="text-2xl font-bold text-gray-900">{metrics.avgScore}%</p>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">Improvement</p>
          <p className="text-2xl font-bold text-gray-900">{metrics.improvement > 0 ? '+' : ''}{metrics.improvement}%</p>
        </div>
      </div>
      
      <h2 className="text-xl font-semibold mb-4 text-gray-800">Session History</h2>
      <table className="w-full text-left">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">Date</th>
            <th className="p-2">Type</th>
            <th className="p-2">Topic</th>
            <th className="p-2">Duration</th>
            <th className="p-2">Score</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map(session => (
            <tr key={session.id} className="border-b">
              <td className="p-2">{new Date(session.created_date).toLocaleDateString()}</td>
              <td className="p-2">{session.type.replace('_', ' ')}</td>
              <td className="p-2">{session.topic || 'N/A'}</td>
              <td className="p-2">{Math.round((session.duration || 0) / 60)}m</td>
              <td className="p-2 font-semibold">{session.overall_score || 0}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
});


export default function Analytics() {
  const [sessions, setSessions] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true); // Fix: useState should be called as a function
  const [selectedTimeframe, setSelectedTimeframe] = useState("all");
  const reportRef = React.useRef();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [userData, sessionsData] = await Promise.all([
        User.me(),
        Session.filter({ created_by: (await User.me()).email }, "-created_date")
      ]);
      setUser(userData);
      setSessions(sessionsData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };
  
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    const reportHtml = reportRef.current.innerHTML;
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Confident.AI - Progress Report</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <style>
            @media print {
              body { -webkit-print-color-adjust: exact; margin: 0; padding: 0; }
              /* Ensure elements like cards background and text colors are printed */
              .bg-gray-50 { background-color: #f9fafb !important; -webkit-print-color-adjust: exact; }
              .confident-glass { background-color: rgba(255, 255, 255, 0.8) !important; -webkit-print-color-adjust: exact; }
              .text-gray-900 { color: #1a202c !important; -webkit-print-color-adjust: exact; }
              .text-gray-600 { color: #4a5568 !important; -webkit-print-color-adjust: exact; }
              .text-gray-500 { color: #718096 !important; -webkit-print-color-adjust: exact; }
              .text-sm { font-size: 0.875rem !important; }
              .text-2xl { font-size: 1.5rem !important; }
              .text-xl { font-size: 1.25rem !important; }
              .font-bold { font-weight: 700 !important; }
              .font-semibold { font-weight: 600 !important; }
            }
          </style>
        </head>
        <body>
          ${reportHtml}
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  const calculateMetrics = () => {
    if (!sessions.length) return {
      totalSessions: 0,
      totalTime: 0,
      avgScore: 0,
      improvement: 0
    };

    const totalSessions = sessions.length;
    const totalTime = sessions.reduce((sum, s) => sum + (s.duration || 0), 0);
    const avgScore = sessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / totalSessions;
    
    let improvement = 0;
    if (sessions.length >= 2) {
      const windowSize = sessions.length >= 6 ? 3 : Math.floor(sessions.length / 2);
      
      const recentSessions = sessions.slice(0, windowSize);
      const olderSessions = sessions.slice(-windowSize);

      const recentAvg = recentSessions.length > 0 ? recentSessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / recentSessions.length : 0;
      const olderAvg = olderSessions.length > 0 ? olderSessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / olderSessions.length : 0;

      if (olderAvg > 0) {
        improvement = ((recentAvg - olderAvg) / olderAvg) * 100;
      } else if (recentAvg > 0) {
        improvement = 100;
      }
    }

    return {
      totalSessions,
      totalTime: Math.round(totalTime / 60), // Convert to minutes
      avgScore: Math.round(avgScore),
      improvement: Math.round(improvement)
    };
  };

  const metrics = calculateMetrics();

  // The exportData function for CSV is removed as it's replaced by PDF export
  // const exportData = () => { ... }

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: 'var(--confident-soft-gray)' }}>
      <style>
        {`
          @media print {
            body { 
              -webkit-print-color-adjust: exact; 
              print-color-adjust: exact;
            }
            .no-print {
              display: none !important;
            }
          }
        `}
      </style>

      {/* Hidden printable component */}
      <div className="hidden">
        <PrintableReport ref={reportRef} sessions={sessions} metrics={metrics} user={user} />
      </div>

      <div className="max-w-7xl mx-auto space-y-8 no-print">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Progress Analytics</h1>
            <p className="text-gray-600">Track your speaking improvement over time</p>
          </div>
          <Button 
            onClick={handlePrint}
            disabled={sessions.length === 0}
            className="confident-gradient text-white hover:opacity-90"
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF Report
          </Button>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="confident-glass border-0 confident-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Sessions</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.totalSessions}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="confident-glass border-0 confident-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Practice Time</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.totalTime}m</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="confident-glass border-0 confident-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Avg Score</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.avgScore}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="confident-glass border-0 confident-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-amber-600 rounded-lg flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Improvement</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.improvement > 0 ? '+' : ''}{metrics.improvement}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <ProgressChart sessions={sessions} isLoading={isLoading} />
            <SkillBreakdown sessions={sessions} isLoading={isLoading} />
          </div>
          
          <div className="space-y-6">
            <InsightsPanel sessions={sessions} />
            <SessionHistory sessions={sessions} isLoading={isLoading} />
          </div>
        </div>
      </div>
    </div>
  );
}
