import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Briefcase, Presentation } from "lucide-react";
import { Session } from "@/entities/Session";

import RecordingInterface from "../components/practice/RecordingInterface";
import PracticeModules from "../components/practice/PracticeModules";
import TopicSelection from "../components/practice/TopicSelection";

export default function Practice() {
  const [selectedModule, setSelectedModule] = useState(null);
  const [isSelectingTopic, setIsSelectingTopic] = useState(false);
  const [practiceTopic, setPracticeTopic] = useState(null);

  const handleSelectModule = (module) => {
    setSelectedModule(module);
    if (module.id === 'speech_practice') {
      setIsSelectingTopic(true);
    } else {
      // For mock interviews and presentations, a random topic is pre-selected
      setPracticeTopic(module.topic);
    }
  };

  const handleTopicConfirm = (topic) => {
    setPracticeTopic(topic);
    setIsSelectingTopic(false);
  };
  
  const handleBack = () => {
    setSelectedModule(null);
    setIsSelectingTopic(false);
    setPracticeTopic(null);
  };

  const renderContent = () => {
    if (isSelectingTopic) {
      return <TopicSelection module={selectedModule} onTopicConfirm={handleTopicConfirm} onBack={handleBack} />;
    }

    if (selectedModule) {
      return (
        <div>
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="outline" 
              onClick={handleBack}
              className="border-indigo-200 text-indigo-700 hover:bg-indigo-50"
            >
              ← Back
            </Button>
            <h2 className="text-2xl font-semibold text-gray-900">
              {selectedModule.name}
            </h2>
          </div>

          {practiceTopic && (
            <div className="mb-6 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <h3 className="font-semibold text-indigo-900 mb-1">Practice Topic</h3>
              <p className="text-indigo-700">{practiceTopic}</p>
            </div>
          )}
          
          <RecordingInterface 
            moduleType={selectedModule.type} 
            topic={practiceTopic}
          />
        </div>
      );
    }

    // Default state: show available practice modules
    return <PracticeModules onSelectModule={handleSelectModule} />;
  }

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: 'var(--confident-soft-gray)' }}>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <Mic className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Practice Session</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Choose a module to start practicing your speech
          </p>
        </div>

        {renderContent()}

      </div>
    </div>
  );
}